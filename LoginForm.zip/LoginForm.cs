﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeChum
{
    public partial class LoginForm : Form

    {

        private Dictionary<string, string> userCredentials = new Dictionary<string, string>
        {
            {"admin", "admin12345" },
            {"user1", "password123" },
            {"student1", "PF101@2024" }
        };
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;


            if (userCredentials.ContainsKey(username) && userCredentials[username] == password)
            {
                resultLabel.Text = "Login Successful";
            }
            else
            {
                resultLabel.Text = "Invalid username or password.";
            }
        }
    }
}
